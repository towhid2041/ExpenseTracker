using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(Expense_Tracker_By_Towhid.StartupOwin))]

namespace Expense_Tracker_By_Towhid
{
    public partial class StartupOwin
    {
        public void Configuration(IAppBuilder app)
        {
            //AuthStartup.ConfigureAuth(app);
        }
    }
}
