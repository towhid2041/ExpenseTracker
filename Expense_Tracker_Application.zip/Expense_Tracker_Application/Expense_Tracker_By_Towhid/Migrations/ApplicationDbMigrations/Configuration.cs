namespace Expense_Tracker_By_Towhid.Migrations.ApplicationDbMigrations
{
    using Expense_Tracker_By_Towhid.Models;
    using Microsoft.AspNet.Identity;
    using Microsoft.AspNet.Identity.EntityFramework;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<Expense_Tracker_By_Towhid.Models.Context.ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            MigrationsDirectory = @"Migrations\ApplicationDbMigrations";
        }

        protected override void Seed(Expense_Tracker_By_Towhid.Models.Context.ApplicationDbContext context)
        {
            var store = new UserStore<ApplicationUser>(context);
            var rStore = new RoleStore<IdentityRole>(context);
            var manager = new UserManager<ApplicationUser>(store);
            var rManager = new RoleManager<IdentityRole>(rStore);
            ApplicationUser Towhid = new ApplicationUser();
            ApplicationUser Admin = new ApplicationUser();
            if (!manager.Users.Any(x => x.UserName == "Towhid"))
            {
                Towhid = new ApplicationUser { UserName = "Towhid" };
                manager.Create(Towhid, "@Open1234");
            }
            if (!manager.Users.Any(x => x.UserName == "Admin"))
            {
                Admin = new ApplicationUser { UserName = "Admin" };
                manager.Create(Admin, "@Open1234");
            }
            if (!rManager.RoleExists("Admins"))
            {
                var role = new IdentityRole("Admins");
                rManager.Create(role);
                manager.AddToRole(Admin.Id, "Admins");
            }
            if (!rManager.RoleExists("Users"))
            {
                var role = new IdentityRole("Users");
                rManager.Create(role);
                manager.AddToRole(Towhid.Id, "Users");
            }
        }
    }
}
