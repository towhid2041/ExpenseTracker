//// -----------------------------------------------------------------------
//// <copyright file="App_Start.cs" company="Fluent.Infrastructure">
////     Copyright © Fluent.Infrastructure. All rights reserved.
//// </copyright>
////-----------------------------------------------------------------------
/// See more at: https://github.com/dn32/Fluent.Infrastructure/wiki
////-----------------------------------------------------------------------

using Fluent.Infrastructure.FluentTools;
using Expense_Tracker_By_Towhid.DataBase;

[assembly: WebActivatorEx.PreApplicationStartMethod(typeof(Expense_Tracker_By_Towhid.App_Start), "PreStart")]

namespace Expense_Tracker_By_Towhid {
    public static class App_Start {
        public static void PreStart() {
            FluentStartup.Initialize(typeof(DbContextLocal));
        }
    }
}