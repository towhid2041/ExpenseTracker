﻿using System.Web;
using System.Web.Mvc;

namespace Expense_Tracker_By_Towhid
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
