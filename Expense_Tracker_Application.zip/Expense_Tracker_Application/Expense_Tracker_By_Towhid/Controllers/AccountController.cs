﻿using Expense_Tracker_By_Towhid.Models;
using Expense_Tracker_By_Towhid.Models.Context;
using Expense_Tracker_By_Towhid.Models.ViewModels;
using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
using Microsoft.Owin.Host.SystemWeb;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Expense_Tracker_By_Towhid.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {

                var context = new ApplicationDbContext();
                var store = new UserStore<ApplicationUser>(context);

                var manager = new Microsoft.AspNet.Identity.UserManager<ApplicationUser>(store);

                var aManager = HttpContext.GetOwinContext().Authentication;

                var user = manager.Find(model.UserName, model.Password);

                if (user != null)
                {
                    var ident = manager.CreateIdentity(user,
                DefaultAuthenticationTypes.ApplicationCookie);
                    //use the instance that has been created. 
                    aManager.SignIn(
                        new AuthenticationProperties { IsPersistent = false }, ident);
                    return Redirect(Url.Action("Index", "Home"));
                }
            }
            ModelState.AddModelError("", "Invalide username or password");
            return View(model);
        }
        [HttpPost]
        public ActionResult Logout()
        {
            var auth = HttpContext.GetOwinContext().Authentication;
            auth.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
            return RedirectToAction("Login");
        }

        public ActionResult Register()
        {
            return View();
        }

    }
}