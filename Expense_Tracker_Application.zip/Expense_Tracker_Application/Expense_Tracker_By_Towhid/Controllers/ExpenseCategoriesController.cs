﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Expense_Tracker_By_Towhid.Models;
using Expense_Tracker_By_Towhid.Models.Context;
using PagedList;

namespace Expense_Tracker_By_Towhid.Controllers
{
    public class ExpenseCategoriesController : Controller
    {
        private readonly ExpenseDbContext db = new ExpenseDbContext();
        

        // GET: ExpenseCategories
        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;

            var categories = from e in db.Categories
                             select e;
            if (!String.IsNullOrEmpty(searchString))
            {
                categories = categories.Where(e => e.CategoryName.Contains(searchString)
                                       );
            }
            switch (sortOrder)
            {
                case "name_desc":
                    categories = categories.OrderByDescending(e => e.CategoryName);
                    break;
                default:
                    categories = categories.OrderBy(e => e.CategoryName);
                    break;
            }

            int pageSize = 3;
            int pageNumber = (page ?? 1);
            return View(categories.ToPagedList(pageNumber, pageSize));
        }

        // GET: ExpenseCategories/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ExpenseCategories/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,CategoryName")] ExpenseCategory expenseCategory)
        {
            if (ModelState.IsValid)
            {
                db.Categories.Add(expenseCategory);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(expenseCategory);
        }

        // GET: ExpenseCategories/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ExpenseCategory expenseCategory = db.Categories.Find(id);
            if (expenseCategory == null)
            {
                return HttpNotFound();
            }
            return View(expenseCategory);
        }

        // POST: ExpenseCategories/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,CategoryName")] ExpenseCategory expenseCategory)
        {
            if (ModelState.IsValid)
            {
                db.Entry(expenseCategory).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(expenseCategory);
        }

        // GET: ExpenseCategories/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ExpenseCategory expenseCategory = db.Categories.Find(id);
            if (expenseCategory == null)
            {
                return HttpNotFound();
            }
            return View(expenseCategory);
        }

        // POST: ExpenseCategories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ExpenseCategory expenseCategory = db.Categories.Find(id);
            db.Categories.Remove(expenseCategory);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
