﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Expense_Tracker_By_Towhid.Models
{
    public class ExpenseCategory
    {
        [Key]
        public int Id { get; set; }
        [Required, StringLength(40), MinLength(2, ErrorMessage = "Minimum length is 2"), Display(Name ="Expense Name")]
        [RegularExpression(@"^[a-zA-Z-]+$", ErrorMessage = "Only letters are allowed")]
        public string CategoryName { get; set; }
        public virtual ICollection<Expense> Expenses { get; set; }
    }
}