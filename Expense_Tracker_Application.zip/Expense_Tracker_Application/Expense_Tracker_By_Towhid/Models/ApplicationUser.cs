﻿using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Expense_Tracker_By_Towhid.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}