﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Expense_Tracker_By_Towhid.Models.Context
{
    public class ExpenseDbContext:DbContext
    {
        public ExpenseDbContext() : base("ExpenseTrackerDbContext") { }
        public DbSet<ExpenseCategory> Categories { get; set; }
        public DbSet<Expense> Expenses { get; set; }
    }
}